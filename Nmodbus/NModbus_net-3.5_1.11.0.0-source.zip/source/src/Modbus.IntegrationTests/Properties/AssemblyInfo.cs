using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Modbus.IntegrationTests")]
[assembly: AssemblyProduct("NModbus")]
[assembly: AssemblyCopyright("Licensed under MIT License.")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("6ddc8745-7d6d-4b5e-8e81-c23c7338bbab")]
[assembly: AssemblyVersion("1.11.0.0")]
[assembly: AssemblyFileVersion("1.11.0.0")]
